package com.varsitycollege.herocollection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Collection;

public class CollectionListView extends AppCompatActivity
{

    private Button btn_Done;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection_list_view);

        btn_Done = findViewById(R.id.btn_Done);

        btn_Done.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //Intent intent = new Intent(CollectionListView.this, MainMenu.class);
                //startActivity(intent);
            }
        });
    }
}