package com.varsitycollege.herocollection;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignIn extends AppCompatActivity
{
    private Account account;
    private TextInputEditText etName;
    private TextInputEditText etSurname;
    private TextInputEditText etEmail;
    private TextInputEditText etPassword;
    private Button btnLogIn;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference heroCollec = database.getReference("Accounts");
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);

        account = new Account();
        etName=findViewById(R.id.et_Name);
        etSurname=findViewById(R.id.et_Surname);
        etEmail=findViewById(R.id.et_email);
        etPassword=findViewById(R.id.et_password);
        btnLogIn=findViewById(R.id.btn_LogIn);

        btnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String surname = etSurname.getText().toString();
                String email =etEmail.getText().toString();
                String password=etPassword.getText().toString();

                if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(surname) && !TextUtils.isEmpty(email)
                        && !TextUtils.isEmpty(password)) {
                    account.setName(name);
                    account.setSurname(surname);
                    account.setEmail(email);
                    account.setPassword(password);

                    heroCollec.push().setValue(account);
                    Intent intent = new Intent(SignIn.this, Login.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(SignIn.this, "Please complete all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}