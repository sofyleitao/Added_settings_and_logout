package com.varsitycollege.herocollection;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;

import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

public class Login extends AppCompatActivity
{

    FirebaseAuth mAuth;

    private TextView email;
    private TextView password;
    private TextView forgotPass;
    private Button login;
    private Button signin;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.emailTyped);
        password = findViewById(R.id.passwordTyped);
        login = findViewById(R.id.btn_login_login);
        signin = findViewById(R.id.btn_Sign_in_login);
        forgotPass = findViewById(R.id.forgot_password);

        mAuth=FirebaseAuth.getInstance();

        login.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                checkData();
                checkCorrectData(email,password);


                /*String email1= email.getText().toString().trim();
                String password2=password.getText().toString().trim();

                mAuth.signInWithEmailAndPassword(email1,password2).addOnCompleteListener(task ->
                {
                    if(task.isSuccessful())
                    {
                        startActivity(new Intent(Login.this, MainMenu.class));
                    }
                    else
                    {
                        Toast.makeText(Login.this,
                                "Please Check Your login Credentials",
                                Toast.LENGTH_SHORT).show();
                    }

                });

                mAuth.signInWithEmailAndPassword(email1, password2).addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>()
                        {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task)
                            {
                                /*if(task.isSuccessful())
                                {
                                    Log.d("My tag","signInWithYourEmail: success!");
                                    FirebaseUser user = mAuth.getCurrentUser();
                                }
                                if (!task.isSuccessful())
                                {
                                    // there was an error
                                    Toast.makeText(Login.this, "Authentication failed." + task.getException(),
                                            Toast.LENGTH_LONG).show();
                                    Log.e("MyTag", task.getException().toString());

                                }
                                else
                                {
                                    Intent intent = new Intent(Login.this, MainMenu.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                        });*/


            }
        });

        signin.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(Login.this, SignIn.class);
                startActivity(intent);
            }
        });

        forgotPass.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                EditText resetMail = new EditText(view.getContext());
                AlertDialog.Builder passwordReset = new AlertDialog.Builder(view.getContext());
                passwordReset.setTitle("Reset your password.");
                passwordReset.setMessage("Please enter your email to reset your forgotten password.");
                passwordReset.setView(resetMail);

                passwordReset.setPositiveButton("Yes", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        String mailing = resetMail.getText().toString();
                        mAuth.sendPasswordResetEmail(mailing).addOnSuccessListener(new OnSuccessListener<Void>()
                        {
                            @Override
                            public void onSuccess(Void aVoid)
                            {
                               Toast.makeText(Login.this,"A link was sent to your email.", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener()
                        {
                            @Override
                            public void onFailure(@NonNull Exception e)
                            {
                                Toast.makeText(Login.this,"There was an error, link was not sent to your email!.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });

                passwordReset.setNegativeButton("No", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i)
                    {

                    }
                });

                passwordReset.create().show();

            }
        });


        ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);

    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void checkData()
    {
        if(email.getText().toString().equals(""))
        {
            Toast.makeText(Login.this,"Please type in your email.",Toast.LENGTH_SHORT).show();
        }
        if(password.getText().toString().equals(""))
        {
            Toast.makeText(Login.this,"Please type in your password.",Toast.LENGTH_SHORT).show();
        }
    }

    public void checkCorrectData(TextView email, TextView password)
    {
        //(email.getText().toString().equals() && password.getText().toString().equals(R.id.passwordTyped))
        //usernameEditText.getText().length() > 0 && passwordEditText.getText().length() > 0

        if(email.getText().length() > 0 && password.getText().length() >0)
        {
            Toast.makeText(Login.this,"YOUR LOGIN IS SUCCESSFUL!!!",Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(Login.this, MainMenu.class);
            startActivity(intent);
        }
        else
        {
            Toast.makeText(Login.this,"FAILED LOGIN!!!",Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(Login.this, MainActivity.class);
            startActivity(intent);
        }


    }
}