package com.varsitycollege.herocollection;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddItems extends AppCompatActivity
{
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference heroCollec = database.getReference("Items");
    private Items items;
    private EditText etItems;
    private EditText etQuantity;
    private EditText etUnit;
    private MultiAutoCompleteTextView txtDescription;
    private EditText etCategory;
    private Button btnAddItem;
    private Button btnLogOutItem;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_items);

        ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);

        items = new Items();
        etItems = findViewById(R.id.et_Items);
        etQuantity=findViewById(R.id.et_Quantity);
        etUnit=findViewById(R.id.et_Unit);
        txtDescription=findViewById(R.id.txtDescription);
        etCategory=findViewById(R.id.et_Category);
        btnAddItem=findViewById(R.id.btn_add_item);
        btnLogOutItem = findViewById(R.id.btn_logout_view);

        btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String item = etItems.getText().toString();
                String quantity = etQuantity.getText().toString();
                String unit = etUnit.getText().toString();
                String description = txtDescription.getText().toString();
                String selecCate = etCategory.getText().toString();

                if (!TextUtils.isEmpty(item) && !TextUtils.isEmpty(quantity) && !TextUtils.isEmpty(unit) && !TextUtils.isEmpty(description)
                        && !TextUtils.isEmpty(selecCate)) {
                    items.setItem(item);
                    items.setQuantity(quantity);
                    items.setUnit(unit);
                    items.setDescription(description);
                    items.setSelecCate(selecCate);

                    heroCollec.push().setValue(items);
                    Intent intent = new Intent(AddItems.this, MainMenu.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(AddItems.this, "Please complete all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnLogOutItem.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(AddItems.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}