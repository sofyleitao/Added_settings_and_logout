package com.varsitycollege.herocollection;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CreateCategory extends AppCompatActivity {
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference heroCollec = database.getReference("categories");
    private Category category;
    private EditText etCate;
    private EditText etCreatedName;
    private Button btnNext;
    private Button btnDone1;
    private Button btnCancel2;
    private Button btnLogoutCat;
    private ImageButton img;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_category);

        category = new Category();
        etCreatedName = findViewById(R.id.et_createdName);
        etCate = findViewById(R.id.et_cate);
        btnNext = findViewById(R.id.btn_Next);
        btnDone1 = findViewById(R.id.btn_Done1);
        btnCancel2 = findViewById(R.id.btn_Cancel2);

        btnLogoutCat = findViewById(R.id.logout);
        img = findViewById(R.id.imageButton2);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);


        btnNext.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {


                String createdName = etCreatedName.getText().toString();
                String cate = etCate.getText().toString();

                if (!TextUtils.isEmpty(createdName) && !TextUtils.isEmpty(cate))
                {
                    category.setCate(cate);
                    category.setCreatedName(createdName);

                    heroCollec.push().setValue(category);
                    Intent intent = new Intent(CreateCategory.this, AddItems.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(CreateCategory.this, "Please complete all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnDone1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(CreateCategory.this, MainMenu.class);
                startActivity(intent);
                String createdName = etCreatedName.getText().toString();
                String cate = etCate.getText().toString();

                if (!TextUtils.isEmpty(createdName) && !TextUtils.isEmpty(cate))
                {
                    category.setCate(cate);
                    category.setCreatedName(createdName);

                    heroCollec.push().setValue(category);

                    String createdNam1 = etCreatedName.getText().toString();
                    Toast.makeText(CreateCategory.this,"Category " + createdNam1 +" has been created!", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Toast.makeText(CreateCategory.this, "Please complete all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnCancel2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(CreateCategory.this, MainMenu.class);
                startActivity(intent);
            }
        });

        btnLogoutCat.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(CreateCategory.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
        public boolean onOptionsItemSelected (@NonNull MenuItem item)
        {
            switch (item.getItemId()) {
                case android.R.id.home:
                    this.finish();
                    return true;
            }
            return super.onOptionsItemSelected(item);
        }
    }

