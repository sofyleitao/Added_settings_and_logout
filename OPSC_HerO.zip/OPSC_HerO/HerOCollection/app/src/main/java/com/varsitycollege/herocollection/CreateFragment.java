package com.varsitycollege.herocollection;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;


public class CreateFragment extends Fragment {

private Button logoutCategory;
private Context CurrentObj=getActivity();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_create, container, false);

        Button btnCatCreate = (Button) view.findViewById(R.id.btnCreateCategory);

        btnCatCreate.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(getActivity(), CreateCategory.class);
                 getActivity().startActivity(intent);

            }
        });

        return view;

    }

}