package com.varsitycollege.herocollection;

public class Category {
    private String createdName;
    private String cate;


    public Category() {

    }

    public Category(String createdName, String cate) {
        this.createdName = createdName;
        this.cate = cate;
    }

    public String getCreatedName() {
        return createdName;
    }

    public void setCreatedName(String createdName) {
        this.createdName = createdName;
    }

    public String getCate() {
        return cate;
    }

    public void setCate(String cate) {
        this.cate = cate;
    }

    @Override
    public String toString() {
        return "Category Name: " + createdName + '\n' +
                "Created: " + cate + '\n' ;
                //"Picture idk: ;
    }
}